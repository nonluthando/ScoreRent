# ScoreRent

ScoreRent is a rental decision‑support web application. It helps renters decide whether a rental listing is worth applying for before paying application fees or investing time. The application evaluates a renter’s profile against a listing and returns a structured result containing:

* A score from 0 to 100
* A verdict (`WORTH_APPLYING`, `BORDERLINE`, `NOT_WORTH_IT`)
* A confidence level (`HIGH`, `MEDIUM`, `LOW`)
* Explanatory reasons
* Recommended actions
* A breakdown of the score by category

## Features

* **Authentication** — Register, log in and log out using session cookies. Passwords are securely hashed.
* **Profile Management** — Create and update a renter profile with income, documents, bursary status and guarantor details.
* **Scoring Engine** — Modular scoring logic evaluates affordability, document readiness, bursary support, guarantor support and listing demand.
* **Evaluation API** — Evaluate listings as a guest (providing inline profile data) or as an authenticated user (using your stored profile). Optionally save evaluations.
* **Saved Evaluations** — List and retrieve saved evaluations with pagination.
* **Web Interface** — Simple Jinja2 templates and static files for demonstration purposes.
* **Testing** — Unit tests for scoring functions and integration tests for the API.
* **Docker Support** — Dockerfile and docker‑compose for local development with PostgreSQL.
* **Continuous Integration** — GitHub Actions workflow runs tests on push and pull requests.

## Project Structure

```
scorerent/
├── app/
│   ├── main.py               # Application factory and router registration
│   ├── core/                 # Configuration, security and session helpers
│   │   ├── config.py
│   │   ├── security.py
│   │   └── sessions.py
│   ├── db/                   # Database engine and ORM models
│   │   ├── database.py
│   │   └── models.py
│   ├── auth/                 # Authentication logic (signup, login, logout)
│   │   ├── router.py
│   │   ├── service.py
│   │   ├── repository.py
│   │   └── schemas.py
│   ├── profiles/             # Profile management (create, update, retrieve)
│   │   ├── router.py
│   │   ├── service.py
│   │   ├── repository.py
│   │   ├── schemas.py
│   │   └── document_schemas.py
│   ├── evaluations/          # Evaluate listings and manage saved evaluations
│   │   ├── router.py
│   │   ├── service.py
│   │   ├── repository.py
│   │   └── schemas.py
│   ├── scoring/              # Modular scoring components and engine
│   │   ├── engine.py
│   │   ├── affordability.py
│   │   ├── documents.py
│   │   ├── bursary.py
│   │   ├── guarantor.py
│   │   ├── confidence.py
│   │   ├── verdicts.py
│   │   └── reasons.py
│   ├── web/                  # Jinja2 templates and static files
│   │   ├── router.py
│   │   ├── templates/
│   │   │   ├── base.html
│   │   │   ├── home.html
│   │   │   ├── login.html
│   │   │   ├── signup.html
│   │   │   ├── profile.html
│   │   │   ├── evaluate.html
│   │   │   └── dashboard.html
│   │   └── static/
│   │       └── css/main.css
│   └── tests/
│       ├── unit/
│       │   └── test_scoring.py
│       └── integration/
│           └── test_api.py
├── Dockerfile                # Docker image definition
├── docker-compose.yml        # Docker Compose for app and PostgreSQL
├── requirements.txt          # Python dependencies
├── .env.example              # Example environment variables
├── .gitignore
└── .github/workflows/ci.yml  # GitHub Actions CI workflow
```

## Running Locally

### Using Docker

```
docker-compose up --build
```

This starts a PostgreSQL database and the FastAPI app. The API will be accessible at `http://localhost:8000`. You can explore the interactive documentation at `http://localhost:8000/docs`.

### Without Docker

Install Python 3.11 and create a virtual environment. Then run:

```
pip install -r requirements.txt

# Set environment variables
export DATABASE_URL=postgresql://postgres:postgres@localhost:5432/scorerent
export SESSION_SECRET_KEY=changeme

# Create database tables
python -c "from scorerent.app.db.database import Base, engine; Base.metadata.create_all(bind=engine)"

uvicorn scorerent.app.main:app --reload
```

You will need a running PostgreSQL instance matching your `DATABASE_URL`.

### Running Tests

To run the test suite:

```
pytest -q scorerent/tests
```

Unit tests cover individual scoring components while integration tests validate the full API flow using an in‑memory SQLite database.

## Contributing

Contributions are welcome! Please open issues or pull requests on GitHub.
