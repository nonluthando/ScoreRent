import os
import tempfile
import json

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from scorerent.app.main import create_app
from scorerent.app.db.database import Base, get_db


@pytest.fixture(scope="module")
def client():
    # Create a temporary SQLite database for testing
    db_fd, db_path = tempfile.mkstemp()
    sql_url = f"sqlite:///{db_path}"
    engine = create_engine(sql_url, connect_args={"check_same_thread": False})
    TestingSessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    Base.metadata.create_all(bind=engine)

    # Dependency override for get_db
    def override_get_db():
        db = TestingSessionLocal()
        try:
            yield db
        finally:
            db.close()

    app = create_app()
    app.dependency_overrides[get_db] = override_get_db

    with TestClient(app) as c:
        yield c

    # Clean up
    os.close(db_fd)
    os.remove(db_path)


def test_signup_login_profile_evaluation_flow(client):
    # Sign up
    resp = client.post("/api/auth/signup", json={"email": "user@example.com", "password": "password123"})
    assert resp.status_code == 201
    user_id = resp.json()["id"]

    # Log in
    resp = client.post("/api/auth/login", json={"email": "user@example.com", "password": "password123"})
    assert resp.status_code == 200

    # Create profile
    profile_payload = {
        "renter_type": "worker",
        "monthly_income": 10000,
        "documents": {
            "payslips": True,
            "bank_statements": True,
            "id_document": True,
            "proof_of_address": True
        },
        "is_bursary_student": False,
        "guarantor": {"has_guarantor": False}
    }
    resp = client.post("/api/profiles", json=profile_payload)
    assert resp.status_code == 201
    profile_id = resp.json()["id"]

    # Evaluate listing without saving
    eval_payload = {
        "listing": {
            "monthly_rent": 2500,
            "demand_level": "MEDIUM",
            "application_fee": 100
        },
        "save": False
    }
    resp = client.post("/api/evaluations", json=eval_payload)
    assert resp.status_code == 200
    data = resp.json()
    assert 0 <= data["score"] <= 100
    assert data["verdict"] in ["WORTH_APPLYING", "BORDERLINE", "NOT_WORTH_IT"]

    # Evaluate listing and save
    eval_payload["save"] = True
    resp = client.post("/api/evaluations", json=eval_payload)
    assert resp.status_code == 200
    saved = resp.json()
    assert "id" in saved
    saved_id = saved["id"]

    # List evaluations
    resp = client.get("/api/evaluations", params={"limit": 10, "offset": 0})
    assert resp.status_code == 200
    evaluations = resp.json()
    assert isinstance(evaluations, list)
    assert any(ev["id"] == saved_id for ev in evaluations)

    # Retrieve saved evaluation
    resp = client.get(f"/api/evaluations/{saved_id}")
    assert resp.status_code == 200
    detailed = resp.json()
    assert detailed["id"] == saved_id