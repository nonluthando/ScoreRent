import pytest

from scorerent.app.scoring.affordability import score_affordability
from scorerent.app.scoring.documents import score_documents
from scorerent.app.scoring.bursary import score_bursary
from scorerent.app.scoring.guarantor import score_guarantor
from scorerent.app.scoring.verdicts import determine_verdict
from scorerent.app.db.models import RenterType, DemandLevel, Verdict


def test_score_affordability():
    # Very affordable
    score, reasons = score_affordability(10000, 2000)
    assert score == 30
    assert "well within" in reasons[0]
    # Affordable
    score, _ = score_affordability(10000, 2800)
    assert score == 25
    # Approaching upper end
    score, _ = score_affordability(10000, 3300)
    assert score == 15
    # High rent
    score, _ = score_affordability(10000, 4000)
    assert score == 5
    # Exceeds limit
    score, _ = score_affordability(10000, 5000)
    assert score == 0


def test_score_documents_worker():
    docs = {"payslips": True, "bank_statements": True, "id_document": True, "proof_of_address": False}
    score, reasons, missing = score_documents(RenterType.WORKER, docs)
    assert score == 15  # 3 docs * 5 points each
    assert missing == 1
    assert any("Missing proof" in r for r in reasons)


def test_score_bursary():
    # Strong buffer
    score, reasons = score_bursary(True, 10000, 4000)
    assert score == 10
    # Moderate buffer
    score, reasons = score_bursary(True, 10000, 9000)
    assert score == 5
    # Low buffer
    score, reasons = score_bursary(True, 10000, 9800)
    assert score == -5
    # Not bursary student
    score, reasons = score_bursary(False, 10000, 4000)
    assert score == 0


def test_score_guarantor():
    score, reasons = score_guarantor({"has_guarantor": True})
    assert score == 5
    assert reasons == ["Guarantor support available"]
    score, reasons = score_guarantor({"has_guarantor": False})
    assert score == 0


def test_determine_verdict():
    assert determine_verdict(85, DemandLevel.HIGH) == Verdict.WORTH_APPLYING
    assert determine_verdict(65, DemandLevel.HIGH) == Verdict.BORDERLINE
    assert determine_verdict(50, DemandLevel.HIGH) == Verdict.NOT_WORTH_IT
    assert determine_verdict(75, DemandLevel.MEDIUM) == Verdict.WORTH_APPLYING
    assert determine_verdict(55, DemandLevel.MEDIUM) == Verdict.BORDERLINE
    assert determine_verdict(45, DemandLevel.MEDIUM) == Verdict.NOT_WORTH_IT
    assert determine_verdict(65, DemandLevel.LOW) == Verdict.WORTH_APPLYING
    assert determine_verdict(45, DemandLevel.LOW) == Verdict.BORDERLINE
    assert determine_verdict(30, DemandLevel.LOW) == Verdict.NOT_WORTH_IT