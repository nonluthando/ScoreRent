"""
HTTP routes for the web interface.

This router serves the home page and other HTML pages via Jinja2 templates.
Currently it provides a simple health check endpoint.
"""

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

router = APIRouter()

# Set up Jinja2 templates directory
templates = Jinja2Templates(directory="app/web/templates")


@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    """
    Render the home page.
    """
    return templates.TemplateResponse("home.html", {"request": request})
