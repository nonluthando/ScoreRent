"""
Document readiness scoring rules.

Evaluates whether the renter has supplied the expected documentation for
their renter type. Missing critical documents reduces the score and
adds explanatory reasons.
"""
from typing import Tuple, List

from app.db.models import RenterType


def score_documents(renter_type: RenterType, documents: dict) -> Tuple[int, List[str], int]:
    """
    Score document readiness for a renter.

    :param renter_type: The renter's type (worker, new professional, student)
    :param documents: Dictionary of document names to boolean indicating presence
    :return: Tuple of (score contribution, reasons, missing_docs_count)
    """
    score = 0
    reasons: List[str] = []
    missing_count = 0

    def check(doc_name: str, description: str, weight: int = 5):
        nonlocal score, missing_count
        if documents.get(doc_name):
            score += weight
        else:
            missing_count += 1
            reasons.append(f"Missing {description}")

    if renter_type == RenterType.WORKER:
        check("payslips", "payslips")
        check("bank_statements", "bank statements")
        check("id_document", "ID document")
        check("proof_of_address", "proof of address")
    elif renter_type == RenterType.NEW_PROFESSIONAL:
        check("payslips", "payslips")
        check("bank_statements", "bank statements")
        check("employment_contract", "employment contract")
        check("id_document", "ID document")
        check("proof_of_address", "proof of address")
    elif renter_type == RenterType.STUDENT:
        # For students, acceptance letter or student card is required
        if documents.get("acceptance_letter") or documents.get("student_card"):
            score += 10
        else:
            missing_count += 1
            reasons.append("Missing acceptance letter or student card")
        check("id_document", "ID document")
        check("proof_of_address", "proof of address")
    else:
        # Unknown renter type, no document scoring
        reasons.append("Unknown renter type for document scoring")

    return score, reasons, missing_count
