"""
Affordability scoring rules.

This module implements functions to score the affordability of a rental
listing relative to a renter's monthly income. It returns both a
numerical contribution towards the final score and qualitative
reasons for the decision.
"""
from typing import Tuple, List


def score_affordability(monthly_income: float, monthly_rent: float) -> Tuple[int, List[str]]:
    """
    Score how affordable the rent is relative to the renter's income.

    :param monthly_income: Renter's monthly income
    :param monthly_rent: Listing's monthly rent
    :return: Tuple of (score contribution, list of reasons)
    """
    reasons: List[str] = []
    if monthly_income <= 0 or monthly_rent <= 0:
        return 0, ["Invalid income or rent provided"]

    ratio = monthly_rent / monthly_income

    if ratio <= 0.25:
        reasons.append("Rent is well within recommended affordability limits")
        return 30, reasons
    elif ratio <= 0.30:
        reasons.append("Rent is affordable relative to income")
        return 25, reasons
    elif ratio <= 0.35:
        reasons.append("Rent is approaching the upper end of affordability")
        return 15, reasons
    elif ratio <= 0.45:
        reasons.append("Rent is high relative to income")
        return 5, reasons
    else:
        reasons.append("Rent exceeds recommended affordability limits")
        return 0, reasons
