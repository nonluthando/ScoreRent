"""
Verdict determination rules.

Maps numerical scores to verdict categories based on listing demand levels.
"""
from app.db.models import Verdict, DemandLevel


def determine_verdict(score: int, demand_level: DemandLevel) -> Verdict:
    """
    Determine the verdict category based on the final score and demand level.

    :param score: Final score (0–100)
    :param demand_level: Listing demand level
    :return: Verdict enumeration value
    """
    if demand_level == DemandLevel.HIGH:
        if score >= 80:
            return Verdict.WORTH_APPLYING
        elif score >= 60:
            return Verdict.BORDERLINE
        else:
            return Verdict.NOT_WORTH_IT
    elif demand_level == DemandLevel.MEDIUM:
        if score >= 70:
            return Verdict.WORTH_APPLYING
        elif score >= 50:
            return Verdict.BORDERLINE
        else:
            return Verdict.NOT_WORTH_IT
    else:  # LOW demand
        if score >= 60:
            return Verdict.WORTH_APPLYING
        elif score >= 40:
            return Verdict.BORDERLINE
        else:
            return Verdict.NOT_WORTH_IT
