"""
Scoring engine coordinating all scoring modules.

This module orchestrates the scoring process by invoking individual scoring
components, calculating the total score, determining the verdict, and
assembling reasons, actions, and the score breakdown.
"""
from typing import Dict, Any

from app.db.models import RenterType, DemandLevel
from .affordability import score_affordability
from .documents import score_documents
from .bursary import score_bursary
from .guarantor import score_guarantor
from .confidence import calculate_confidence
from .verdicts import determine_verdict
from .reasons import aggregate_reasons, generate_actions


def evaluate_profile_and_listing(profile: Any, listing: Dict[str, Any]) -> Dict[str, Any]:
    """
    Evaluate a renter profile against a listing and return the structured result.

    :param profile: Profile ORM instance or similar object with attributes
    :param listing: Dictionary containing listing information including monthly_rent,
                    demand_level, application_fee, etc.
    :return: Dictionary with the evaluation result
    """
    monthly_income = profile.monthly_income
    monthly_rent = listing.get("monthly_rent")
    if monthly_rent is None:
        raise ValueError("Listing must include 'monthly_rent'")

    demand_level = listing.get("demand_level", DemandLevel.MEDIUM)
    if isinstance(demand_level, str):
        demand_level = DemandLevel(demand_level)

    # Scoring components
    total_score = 0
    breakdown: Dict[str, int] = {}
    reasons_lists = []

    # Affordability
    score, reasons = score_affordability(monthly_income, monthly_rent)
    total_score += score
    breakdown["affordability"] = score
    reasons_lists.append(reasons)

    # Document readiness
    doc_score, doc_reasons, missing_docs = score_documents(profile.renter_type, profile.documents_json or {})
    total_score += doc_score
    breakdown["documents"] = doc_score
    reasons_lists.append(doc_reasons)

    # Bursary support
    bursary_score, bursary_reasons = score_bursary(
        profile.is_bursary_student,
        monthly_income,
        monthly_rent,
    )
    total_score += bursary_score
    breakdown["bursary"] = bursary_score
    reasons_lists.append(bursary_reasons)

    # Guarantor
    guarantor_score, guarantor_reasons = score_guarantor(profile.guarantor_json)
    total_score += guarantor_score
    breakdown["guarantor"] = guarantor_score
    reasons_lists.append(guarantor_reasons)

    # Demand adjustment
    if demand_level == DemandLevel.HIGH:
        total_score -= 10
        breakdown["demand"] = -10
        reasons_lists.append(["Listing is in high demand, increasing competition"])
    elif demand_level == DemandLevel.LOW:
        total_score += 5
        breakdown["demand"] = 5
        reasons_lists.append(["Listing demand is low, easier to secure"])
    else:
        breakdown["demand"] = 0

    # Clamp score between 0 and 100
    if total_score < 0:
        total_score = 0
    if total_score > 100:
        total_score = 100

    # Determine verdict
    verdict = determine_verdict(int(total_score), demand_level)

    # Confidence
    confidence = calculate_confidence(missing_docs)

    # Aggregate reasons and generate actions
    reasons = aggregate_reasons(*reasons_lists)
    actions = generate_actions(missing_docs, profile.is_bursary_student)

    return {
        "score": int(total_score),
        "verdict": verdict,
        "confidence": confidence,
        "reasons": reasons,
        "actions": actions,
        "breakdown": breakdown,
    }
