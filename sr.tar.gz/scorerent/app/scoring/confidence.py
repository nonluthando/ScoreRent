"""
Confidence level calculation.

Determines a qualitative confidence level for an evaluation based on the
number of missing documents and other weak signals.
"""


def calculate_confidence(missing_docs: int) -> str:
    """
    Calculate the confidence level based on the number of missing documents.

    :param missing_docs: Count of missing required documents
    :return: Confidence level: HIGH, MEDIUM, or LOW
    """
    if missing_docs == 0:
        return "HIGH"
    elif missing_docs <= 2:
        return "MEDIUM"
    else:
        return "LOW"
