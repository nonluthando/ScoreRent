"""
Bursary scoring rules.

Provides additional score contributions or penalties for bursary students
based on their remaining income after rent.
"""
from typing import Tuple, List


def score_bursary(is_bursary_student: bool, monthly_income: float, monthly_rent: float) -> Tuple[int, List[str]]:
    """
    Score bursary support for a renter.

    :param is_bursary_student: Whether the renter receives a bursary
    :param monthly_income: Renter's monthly income
    :param monthly_rent: Listing rent per month
    :return: Tuple of (score contribution, list of reasons)
    """
    reasons: List[str] = []
    if not is_bursary_student:
        return 0, reasons

    buffer = monthly_income - monthly_rent
    if buffer >= 4000:
        reasons.append("Bursary provides a strong buffer after rent")
        return 10, reasons
    elif buffer >= 1500:
        reasons.append("Bursary provides a modest buffer after rent")
        return 5, reasons
    else:
        reasons.append("Bursary buffer is low; consider reducing rent or seeking additional support")
        return -5, reasons
