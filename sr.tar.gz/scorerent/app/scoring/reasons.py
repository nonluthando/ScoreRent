"""
Reasons and recommended actions generator.

Aggregates reasons from various scoring components and generates specific
recommendations to improve the renter's match for future applications.
"""
from typing import List, Dict


def aggregate_reasons(*reasons_lists: List[List[str]]) -> List[str]:
    """
    Flatten multiple lists of reasons into a single list.

    :param reasons_lists: Variable number of reason lists
    :return: Flattened list of reasons
    """
    flat: List[str] = []
    for lst in reasons_lists:
        flat.extend(lst)
    # Deduplicate while preserving order
    seen = set()
    deduped = []
    for reason in flat:
        if reason not in seen:
            seen.add(reason)
            deduped.append(reason)
    return deduped


def generate_actions(missing_docs_count: int, is_bursary_student: bool) -> List[str]:
    """
    Generate recommended actions based on evaluation shortcomings.

    :param missing_docs_count: Number of missing documents
    :param is_bursary_student: Whether the renter is a bursary student
    :return: List of actionable recommendations
    """
    actions: List[str] = []
    if missing_docs_count > 0:
        actions.append("Provide all required documents to improve confidence")
    if is_bursary_student:
        actions.append("Ensure sufficient bursary coverage remains after rent")
    if missing_docs_count == 0 and not is_bursary_student:
        actions.append("Prepare to submit application as your profile is strong")
    return actions
