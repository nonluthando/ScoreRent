"""
Guarantor scoring rules.

Adds bonus points if a guarantor is available. Guarantor information
should be provided as a dictionary with at least a boolean flag.
"""
from typing import Tuple, List, Optional, Dict


def score_guarantor(guarantor: Optional[Dict]) -> Tuple[int, List[str]]:
    """
    Score guarantor support for a renter.

    :param guarantor: Dictionary containing guarantor information or None
    :return: Tuple of (score contribution, list of reasons)
    """
    reasons: List[str] = []
    if guarantor and guarantor.get("has_guarantor"):
        # Bonus points for having a guarantor
        reasons.append("Guarantor support available")
        return 5, reasons
    return 0, reasons
