"""
Pydantic schemas for authentication operations.

These schemas define the shape of data sent to and from authentication endpoints.
"""
from pydantic import BaseModel, EmailStr, Field


class UserCreate(BaseModel):
    """
    Schema for user registration.
    """

    email: EmailStr
    password: str = Field(min_length=8)


class UserLogin(BaseModel):
    """
    Schema for user login requests.
    """

    email: EmailStr
    password: str


class UserRead(BaseModel):
    """
    Schema for responses containing user information.
    """

    id: int
    email: EmailStr

    model_config = {
        "from_attributes": True,
    }
