"""
Business logic for authentication.

This module orchestrates user creation and verification.
"""
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.auth.repository import create_user, get_user_by_email
from app.auth.schemas import UserCreate, UserLogin
from app.core.security import hash_password, verify_password
from app.db.models import User


def register_user(db: Session, user_data: UserCreate) -> User:
    """
    Register a new user.

    :param db: Database session
    :param user_data: User creation data
    :return: New user instance
    :raises HTTPException: if email already registered
    """
    existing_user = get_user_by_email(db, user_data.email)

    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered",
        )

    password_hash = hash_password(user_data.password)

    return create_user(
        db=db,
        email=user_data.email,
        password_hash=password_hash,
    )


def authenticate_user(db: Session, login_data: UserLogin) -> User:
    """
    Authenticate a user by verifying email and password.

    :param db: Database session
    :param login_data: User login data
    :return: Authenticated user instance
    :raises HTTPException: if credentials are invalid
    """
    user = get_user_by_email(db, login_data.email)

    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",
        )

    if not verify_password(login_data.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",
        )

    return user
