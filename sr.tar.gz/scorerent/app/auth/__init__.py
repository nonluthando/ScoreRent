# Authentication package for user registration, login and logout
