"""
HTTP routes for authentication.

This module defines endpoints for user registration, login and logout.
Routes are grouped under the /api/auth prefix and tagged accordingly.
"""
from fastapi import APIRouter, Depends, Request, Response, status
from sqlalchemy.orm import Session

from app.auth.schemas import UserCreate, UserLogin, UserRead
from app.auth.service import authenticate_user, register_user
from app.core.sessions import login_user, logout_user
from app.db.database import get_db


router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/signup", response_model=UserRead, status_code=status.HTTP_201_CREATED)
def signup(user_data: UserCreate, db: Session = Depends(get_db)):
    """
    Register a new user.

    :param user_data: User registration data
    :param db: Database session dependency
    :return: Created user details
    """
    user = register_user(db, user_data)
    return user


@router.post("/login", response_model=UserRead)
def login(
    request: Request,
    login_data: UserLogin,
    db: Session = Depends(get_db),
):
    """
    Log in a user and create a session.

    :param request: FastAPI request object (contains session)
    :param login_data: User login data
    :param db: Database session dependency
    :return: Authenticated user details
    """
    user = authenticate_user(db, login_data)
    login_user(request, user)
    return user


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(request: Request):
    """
    Log out the current user by clearing the session.

    :param request: FastAPI request object
    :return: 204 No Content response
    """
    logout_user(request)
    return Response(status_code=status.HTTP_204_NO_CONTENT)
