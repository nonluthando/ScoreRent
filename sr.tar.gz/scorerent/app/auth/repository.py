"""
Data access layer for authentication.

Contains functions that encapsulate database operations for user management.
"""
from sqlalchemy.orm import Session

from app.db.models import User


def get_user_by_email(db: Session, email: str) -> User | None:
    """
    Retrieve a user by email.

    :param db: Database session
    :param email: User email
    :return: User instance or None if not found
    """
    return db.query(User).filter(User.email == email).first()


def create_user(db: Session, email: str, password_hash: str) -> User:
    """
    Create a new user with the given email and password hash.

    :param db: Database session
    :param email: User email
    :param password_hash: Hashed password
    :return: Newly created User instance
    """
    user = User(email=email, password_hash=password_hash)

    db.add(user)
    db.commit()
    db.refresh(user)

    return user
