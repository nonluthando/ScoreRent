"""
Session management helpers.

This module provides helper functions to manage user sessions using FastAPI's
SessionMiddleware. Sessions store the logged-in user's ID in a cookie.
"""

from fastapi import HTTPException, Request, status, Depends
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.db.models import User

# Key used to store the user ID in the session cookie
SESSION_USER_ID = "user_id"


def login_user(request: Request, user: User) -> None:
    """
    Store the user's ID in the session to indicate an authenticated session.

    :param request: FastAPI request object
    :param user: Authenticated user instance
    """
    request.session[SESSION_USER_ID] = user.id


def logout_user(request: Request) -> None:
    """
    Clear the session completely, effectively logging out the user.

    :param request: FastAPI request object
    """
    request.session.clear()


def get_current_user(
    request: Request,
    db: Session = Depends(get_db),
) -> User:
    """
    Retrieve the currently logged-in user based on the session.

    :param request: FastAPI request object
    :param db: SQLAlchemy database session
    :return: User instance
    :raises HTTPException: if no valid session is found
    """
    user_id = request.session.get(SESSION_USER_ID)

    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
        )

    user = db.get(User, user_id)

    if not user:
        # Clear invalid sessions to avoid repeated queries
        request.session.clear()
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid session",
        )

    return user
