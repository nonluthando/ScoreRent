"""
Application configuration using Pydantic settings.

This module defines the Settings class which centralises configuration
for the application such as the database URL and session secret key.
Environment variables are loaded from a `.env` file located at the project root.
"""

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    Base settings for the ScoreRent application.
    """

    DATABASE_URL: str
    SESSION_SECRET_KEY: str

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


# Instantiate a single settings object to be imported throughout the project.
settings = Settings()
