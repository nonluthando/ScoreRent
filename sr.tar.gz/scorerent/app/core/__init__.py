# Core package for configuration, security and session management utilities
