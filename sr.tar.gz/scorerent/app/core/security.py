"""
Security utilities for password hashing and verification.

This module wraps passlib's CryptContext to provide a single place to
hash and verify passwords. Using a context allows us to upgrade hashing
algorithms in the future without changing the rest of the code.
"""

from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    """
    Hash a plain text password using bcrypt.

    :param password: Plain text password
    :return: Hashed password string
    """
    return pwd_context.hash(password)


def verify_password(plain_password: str, password_hash: str) -> bool:
    """
    Verify that a plain password matches a hashed password.

    :param plain_password: User provided plain password
    :param password_hash: Stored hashed password
    :return: True if the password matches, False otherwise
    """
    return pwd_context.verify(plain_password, password_hash)
