from fastapi import FastAPI
from starlette.middleware.sessions import SessionMiddleware

from app.core.config import settings
from app.auth.router import router as auth_router
from app.web.router import router as web_router
from app.profiles.router import router as profiles_router
from app.evaluations.router import router as evaluations_router
from fastapi.staticfiles import StaticFiles


def create_app() -> FastAPI:
    """
    Application factory responsible for creating and configuring the FastAPI instance.
    Registers middleware and routers here.
    """
    app = FastAPI(title="ScoreRent")

    # Session middleware for cookie-based authentication
    app.add_middleware(
        SessionMiddleware,
        secret_key=settings.SESSION_SECRET_KEY,
        session_cookie="scorerent_session",
        same_site="lax",
        https_only=False,
    )

    # Mount static files for CSS, JS, etc.
    app.mount("/static", StaticFiles(directory="app/web/static"), name="static")

    # Register API routers
    app.include_router(auth_router)
    app.include_router(web_router)
    app.include_router(profiles_router)
    app.include_router(evaluations_router)

    return app


app = create_app()
