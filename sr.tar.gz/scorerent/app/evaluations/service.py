"""
Business logic for listing evaluations.

This service layer orchestrates the evaluation process, including scoring,
saving evaluations when requested, and retrieving saved evaluations.
"""
from typing import Optional
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.scoring.engine import evaluate_profile_and_listing
from app.evaluations.repository import (
    create_evaluation as repo_create_evaluation,
    list_evaluations as repo_list_evaluations,
    get_evaluation as repo_get_evaluation,
)
from app.evaluations.schemas import EvaluationRequest
from app.profiles.service import get_profile
from app.db.models import User


def evaluate_listing(
    db: Session,
    user: Optional[User],
    request_data: EvaluationRequest,
) -> dict:
    """
    Evaluate a listing using a renter profile and optionally save the result.

    :param db: Database session
    :param user: Authenticated user or None for guest
    :param request_data: Evaluation request containing listing and optional profile
    :return: Evaluation result dictionary
    """
    # Determine which profile to use
    if user is None:
        # Guest evaluation: profile must be included in request
        profile_data = request_data.profile
        if not profile_data:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Profile must be provided for guest evaluations")
        # Create a simple object with attributes like the Profile ORM
        class TempProfile:
            pass
        temp_profile = TempProfile()
        temp_profile.monthly_income = profile_data.monthly_income
        temp_profile.renter_type = profile_data.renter_type
        temp_profile.documents_json = profile_data.documents.dict() if profile_data.documents else {}
        temp_profile.is_bursary_student = profile_data.is_bursary_student
        temp_profile.guarantor_json = profile_data.guarantor.dict() if profile_data.guarantor else {}
        profile = temp_profile
        profile_id = None
        user_id = None
    else:
        # Authenticated evaluation: fetch profile from DB
        profile = get_profile(db, user.id)
        if not profile:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="User must create a profile before evaluating listings")
        profile_id = profile.id
        user_id = user.id

    # Evaluate using scoring engine
    listing_dict = request_data.listing.dict()
    result = evaluate_profile_and_listing(profile, listing_dict)

    # Optionally save the result
    if request_data.save and user_id is not None:
        evaluation = repo_create_evaluation(
            db,
            user_id=user_id,
            profile_id=profile_id,
            listing_data=listing_dict,
            result=result,
        )
        result["id"] = evaluation.id
        result["created_at"] = evaluation.created_at.isoformat()
    return result


def list_saved_evaluations(db: Session, user: User, limit: int, offset: int) -> list:
    """
    List evaluations saved by the authenticated user.

    :param db: Database session
    :param user: Authenticated user
    :param limit: Limit for pagination
    :param offset: Offset for pagination
    :return: List of evaluation result dicts
    """
    evaluations = repo_list_evaluations(db, user.id, limit, offset)
    results = []
    for ev in evaluations:
        results.append({
            "id": ev.id,
            "score": ev.score,
            "verdict": ev.verdict,
            "confidence": ev.confidence,
            "reasons": ev.reasons_json,
            "actions": ev.actions_json,
            "breakdown": ev.breakdown_json,
            "created_at": ev.created_at.isoformat(),
        })
    return results


def get_saved_evaluation(db: Session, user: User, evaluation_id: int) -> dict:
    """
    Retrieve a saved evaluation by its ID.

    :param db: Database session
    :param user: Authenticated user
    :param evaluation_id: ID of the evaluation to retrieve
    :return: Evaluation result dictionary
    :raises HTTPException: if evaluation is not found or belongs to another user
    """
    ev = repo_get_evaluation(db, user.id, evaluation_id)
    if not ev:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Evaluation not found")
    return {
        "id": ev.id,
        "score": ev.score,
        "verdict": ev.verdict,
        "confidence": ev.confidence,
        "reasons": ev.reasons_json,
        "actions": ev.actions_json,
        "breakdown": ev.breakdown_json,
        "created_at": ev.created_at.isoformat(),
    }
