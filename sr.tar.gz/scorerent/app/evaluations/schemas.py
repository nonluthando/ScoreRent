"""
Pydantic schemas for evaluation endpoints.

Defines the shape of incoming requests and outgoing responses for evaluating
listings against renter profiles.
"""
from typing import Optional, Dict, Any, List
from pydantic import BaseModel

from app.db.models import DemandLevel, Verdict
from app.profiles.schemas import Documents, Guarantor
from app.profiles.schemas import ProfileRead


class ListingData(BaseModel):
    """
    Input schema representing the details of a rental listing.
    """

    monthly_rent: float
    demand_level: DemandLevel = DemandLevel.MEDIUM
    application_fee: Optional[float] = None


class EvaluationRequest(BaseModel):
    """
    Request schema for evaluating a listing. When evaluating as a guest,
    the profile data is included inline; otherwise, the server uses the
    authenticated user's stored profile.
    """

    listing: ListingData
    profile: Optional[ProfileRead] = None
    save: bool = False


class EvaluationResult(BaseModel):
    """
    Response schema for an evaluation result.
    """

    score: int
    verdict: Verdict
    confidence: str
    reasons: List[str]
    actions: List[str]
    breakdown: Dict[str, int]


class SavedEvaluation(EvaluationResult):
    """
    Response schema for a saved evaluation, includes identifier and timestamp.
    """

    id: int
    created_at: str
