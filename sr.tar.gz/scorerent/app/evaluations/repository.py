"""
Data access layer for evaluations.

Provides functions to persist evaluations and retrieve them for users.
"""
from typing import List, Optional
from sqlalchemy.orm import Session

from app.db.models import Evaluation


def create_evaluation(
    db: Session,
    *,
    user_id: Optional[int],
    profile_id: Optional[int],
    listing_data: dict,
    result: dict,
) -> Evaluation:
    """
    Save a new evaluation to the database.

    :param db: Database session
    :param user_id: ID of the user who performed the evaluation (None for guest)
    :param profile_id: ID of the profile used for evaluation (None for guest)
    :param listing_data: Original listing input as dictionary
    :param result: Evaluation result from the scoring engine
    :return: Newly created Evaluation instance
    """
    evaluation = Evaluation(
        user_id=user_id,
        profile_id=profile_id,
        listing_json=listing_data,
        score=result["score"],
        verdict=result["verdict"],
        confidence=result["confidence"],
        reasons_json=result["reasons"],
        actions_json=result["actions"],
        breakdown_json=result["breakdown"],
    )
    db.add(evaluation)
    db.commit()
    db.refresh(evaluation)
    return evaluation


def list_evaluations(db: Session, user_id: int, limit: int, offset: int) -> List[Evaluation]:
    """
    Retrieve a paginated list of evaluations for a user.

    :param db: Database session
    :param user_id: ID of the user
    :param limit: Number of results to return
    :param offset: Offset for pagination
    :return: List of Evaluation instances
    """
    return (
        db.query(Evaluation)
        .filter(Evaluation.user_id == user_id)
        .order_by(Evaluation.created_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )


def get_evaluation(db: Session, user_id: int, evaluation_id: int) -> Optional[Evaluation]:
    """
    Retrieve a single evaluation by ID for a user.

    :param db: Database session
    :param user_id: ID of the user
    :param evaluation_id: ID of the evaluation
    :return: Evaluation instance or None
    """
    return (
        db.query(Evaluation)
        .filter(Evaluation.user_id == user_id, Evaluation.id == evaluation_id)
        .first()
    )
