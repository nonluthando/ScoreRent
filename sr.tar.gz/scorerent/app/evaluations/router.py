"""
HTTP routes for evaluations.

Endpoints for performing evaluations (guest and authenticated), listing
saved evaluations and retrieving individual evaluation details.
"""
from fastapi import APIRouter, Depends, Query, HTTPException, status
from sqlalchemy.orm import Session

from app.core.sessions import get_current_user
from app.db.database import get_db
from app.evaluations.schemas import EvaluationRequest, EvaluationResult
from app.evaluations.service import evaluate_listing, list_saved_evaluations, get_saved_evaluation
from app.db.models import User


router = APIRouter(prefix="/api/evaluations", tags=["evaluations"])


@router.post("/guest", response_model=EvaluationResult)
def evaluate_as_guest(
    *,
    request: EvaluationRequest,
    db: Session = Depends(get_db),
):
    """
    Evaluate a listing using profile data supplied in the request body.
    The result is not saved.
    """
    return evaluate_listing(db, None, request)


@router.post("", response_model=EvaluationResult)
def evaluate_and_optionally_save(
    *,
    request: EvaluationRequest,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """
    Evaluate a listing using the authenticated user's stored profile.
    If `save` is true in the request, the result is stored in the database.
    """
    return evaluate_listing(db, user, request)


@router.get("", response_model=list[EvaluationResult])
def list_evaluations(
    *,
    limit: int = Query(10, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """
    List evaluations saved by the authenticated user. Supports pagination.
    """
    return list_saved_evaluations(db, user, limit, offset)


@router.get("/{evaluation_id}", response_model=EvaluationResult)
def get_evaluation_by_id(
    *,
    evaluation_id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """
    Retrieve a single saved evaluation by its ID. Returns 404 if not found
    or belongs to another user.
    """
    return get_saved_evaluation(db, user, evaluation_id)
