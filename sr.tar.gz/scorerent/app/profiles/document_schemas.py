"""
Pydantic models for nested documents and guarantor data.

These schemas provide a structured representation of profile documents and
guarantor details. They are stored as JSON in the database but handled
as typed objects in the application.
"""

from pydantic import BaseModel
from typing import Optional


class Documents(BaseModel):
    """
    Structure representing various documents that may be provided by a renter.

    Each field is a boolean indicating whether the document has been supplied.
    """

    payslips: bool = False
    bank_statements: bool = False
    id_document: bool = False
    proof_of_address: bool = False
    employment_contract: bool = False
    student_card: bool = False
    acceptance_letter: bool = False


class Guarantor(BaseModel):
    """
    Information about a guarantor supporting the renter.

    - has_guarantor: indicates whether a guarantor exists.
    - monthly_income: the guarantor's monthly income (optional).
    - relationship: the guarantor's relationship to the renter (optional).
    """

    has_guarantor: bool = False
    monthly_income: Optional[float] = None
    relationship: Optional[str] = None
