"""
Pydantic schemas for profile operations.

These models define the shape of data used when creating, updating and
reading renter profiles. They include nested document and guarantor
structures for better type safety and clarity in code.
"""
from typing import Optional
from pydantic import BaseModel

from app.db.models import RenterType
from .document_schemas import Documents, Guarantor


class ProfileBase(BaseModel):
    """
    Base schema for profile data shared across create, update and read.
    """

    renter_type: RenterType
    monthly_income: float
    documents: Documents
    is_bursary_student: bool = False
    guarantor: Optional[Guarantor] = None


class ProfileCreate(ProfileBase):
    """
    Schema for creating a new profile. Inherits all fields from ProfileBase.
    """

    pass


class ProfileUpdate(BaseModel):
    """
    Schema for updating an existing profile.

    All fields are optional to allow partial updates. Missing fields will
    not be updated in the database.
    """

    renter_type: Optional[RenterType] = None
    monthly_income: Optional[float] = None
    documents: Optional[Documents] = None
    is_bursary_student: Optional[bool] = None
    guarantor: Optional[Guarantor] = None


class ProfileRead(ProfileBase):
    """
    Schema for reading profile information back to the client.
    Includes the database identifier.
    """

    id: int

    class Config:
        orm_mode = True
