"""
HTTP routes for profile management.

Defines endpoints for creating, retrieving and updating renter profiles.
All endpoints require an authenticated user.
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.sessions import get_current_user
from app.db.database import get_db
from app.profiles.schemas import ProfileCreate, ProfileUpdate, ProfileRead
from app.profiles.service import create_profile as svc_create_profile, update_profile as svc_update_profile, get_profile as svc_get_profile


router = APIRouter(prefix="/api/profiles", tags=["profiles"])


@router.get("/me", response_model=ProfileRead)
def get_my_profile(
    *,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    """
    Retrieve the current user's profile.

    Returns a 404 error if no profile exists for the user.
    """
    profile = svc_get_profile(db, user.id)
    if not profile:
        # Explicitly raise HTTPException for 404 when no profile exists
        from fastapi import HTTPException, status

        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Profile not found")
    # Convert nested JSON to structured responses
    return ProfileRead(
        id=profile.id,
        renter_type=profile.renter_type,
        monthly_income=profile.monthly_income,
        documents=profile.documents_json or {},
        is_bursary_student=profile.is_bursary_student,
        guarantor=profile.guarantor_json,
    )


@router.post("", response_model=ProfileRead, status_code=201)
def create_my_profile(
    *,
    profile_data: ProfileCreate,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    """
    Create a new profile for the authenticated user.

    Returns 400 if a profile already exists.
    """
    profile = svc_create_profile(db, user.id, profile_data)
    return ProfileRead(
        id=profile.id,
        renter_type=profile.renter_type,
        monthly_income=profile.monthly_income,
        documents=profile.documents_json or {},
        is_bursary_student=profile.is_bursary_student,
        guarantor=profile.guarantor_json,
    )


@router.put("/me", response_model=ProfileRead)
def update_my_profile(
    *,
    update_data: ProfileUpdate,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    """
    Update the authenticated user's profile.
    Returns 404 if no profile exists.
    """
    profile = svc_update_profile(db, user.id, update_data)
    return ProfileRead(
        id=profile.id,
        renter_type=profile.renter_type,
        monthly_income=profile.monthly_income,
        documents=profile.documents_json or {},
        is_bursary_student=profile.is_bursary_student,
        guarantor=profile.guarantor_json,
    )
