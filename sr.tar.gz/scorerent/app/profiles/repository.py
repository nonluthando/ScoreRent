"""
Data access layer for profiles.

This module encapsulates all database operations related to renter profiles.
"""
from sqlalchemy.orm import Session
from sqlalchemy import update as sa_update

from app.db.models import Profile


def get_profile_by_user_id(db: Session, user_id: int) -> Profile | None:
    """
    Retrieve a profile by the owning user's ID.

    :param db: Database session
    :param user_id: ID of the user
    :return: Profile instance or None if not found
    """
    return db.query(Profile).filter(Profile.user_id == user_id).first()


def create_profile(
    db: Session,
    *,
    user_id: int,
    renter_type: str,
    monthly_income: float,
    documents: dict,
    is_bursary_student: bool,
    guarantor: dict | None,
) -> Profile:
    """
    Create and persist a new profile for a user.

    :param db: Database session
    :param user_id: User ID (must be unique across profiles)
    :param renter_type: Renter type (value of RenterType enum)
    :param monthly_income: Monthly income of the renter
    :param documents: JSON-serialisable documents dictionary
    :param is_bursary_student: Whether the renter is a bursary student
    :param guarantor: JSON-serialisable guarantor dictionary or None
    :return: Newly created Profile instance
    """
    profile = Profile(
        user_id=user_id,
        renter_type=renter_type,
        monthly_income=monthly_income,
        documents_json=documents,
        is_bursary_student=is_bursary_student,
        guarantor_json=guarantor,
    )
    db.add(profile)
    db.commit()
    db.refresh(profile)
    return profile


def update_profile(db: Session, profile: Profile, update_data: dict) -> Profile:
    """
    Update a profile with the provided fields.

    Only fields present in update_data will be updated. After updating,
    the profile is refreshed from the database.

    :param db: Database session
    :param profile: Profile instance to update
    :param update_data: Dict of fields to update
    :return: Updated Profile instance
    """
    for key, value in update_data.items():
        setattr(profile, key, value)
    db.commit()
    db.refresh(profile)
    return profile
