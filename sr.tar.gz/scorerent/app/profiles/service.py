"""
Business logic for profile management.

This module orchestrates profile creation, retrieval and updates. It ensures
that each user has at most one profile and handles conversion between
Pydantic models and database representations.
"""
from typing import Optional
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.db.models import Profile
from app.profiles.schemas import ProfileCreate, ProfileUpdate
from app.profiles.repository import (
    get_profile_by_user_id,
    create_profile as repo_create_profile,
    update_profile as repo_update_profile,
)


def get_profile(db: Session, user_id: int) -> Optional[Profile]:
    """
    Retrieve a profile for the given user ID.

    :param db: Database session
    :param user_id: User ID
    :return: Profile or None
    """
    return get_profile_by_user_id(db, user_id)


def create_profile(db: Session, user_id: int, profile_data: ProfileCreate) -> Profile:
    """
    Create a new profile for a user.

    Raises HTTP 400 if the user already has a profile.

    :param db: Database session
    :param user_id: User ID
    :param profile_data: Data for profile creation
    :return: Created Profile
    :raises HTTPException: if profile already exists
    """
    existing = get_profile_by_user_id(db, user_id)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Profile already exists",
        )
    return repo_create_profile(
        db,
        user_id=user_id,
        renter_type=profile_data.renter_type.value,
        monthly_income=profile_data.monthly_income,
        documents=profile_data.documents.dict(),
        is_bursary_student=profile_data.is_bursary_student,
        guarantor=profile_data.guarantor.dict() if profile_data.guarantor else None,
    )


def update_profile(db: Session, user_id: int, update_data: ProfileUpdate) -> Profile:
    """
    Update an existing profile.

    Raises HTTP 404 if the profile does not exist.

    :param db: Database session
    :param user_id: User ID
    :param update_data: Data for profile update
    :return: Updated Profile
    :raises HTTPException: if profile does not exist
    """
    profile = get_profile_by_user_id(db, user_id)
    if not profile:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Profile not found",
        )

    # Build a dict of updates; convert nested Pydantic objects to dicts
    updates: dict = {}
    if update_data.renter_type is not None:
        updates["renter_type"] = update_data.renter_type.value
    if update_data.monthly_income is not None:
        updates["monthly_income"] = update_data.monthly_income
    if update_data.documents is not None:
        updates["documents_json"] = update_data.documents.dict()
    if update_data.is_bursary_student is not None:
        updates["is_bursary_student"] = update_data.is_bursary_student
    if update_data.guarantor is not None:
        updates["guarantor_json"] = update_data.guarantor.dict() if update_data.guarantor else None

    return repo_update_profile(db, profile, updates)
