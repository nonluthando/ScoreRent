"""
Database models and enumerations.

This file defines SQLAlchemy ORM models representing the users, profiles,
and evaluations tables. It also defines enumerations used across the application.
"""
from datetime import datetime
from enum import Enum

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, JSON, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


class RenterType(str, Enum):
    """
    Enumeration representing the main renter types.
    """

    WORKER = "worker"
    NEW_PROFESSIONAL = "new_professional"
    STUDENT = "student"


class Verdict(str, Enum):
    """
    Possible verdicts for a rental evaluation.
    """

    WORTH_APPLYING = "WORTH_APPLYING"
    BORDERLINE = "BORDERLINE"
    NOT_WORTH_IT = "NOT_WORTH_IT"


class ConfidenceLevel(str, Enum):
    """
    Confidence levels for evaluation results.
    """

    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class DemandLevel(str, Enum):
    """
    Demand levels used to adjust evaluation scores.
    """

    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


class User(Base):
    """
    User model representing registered users.
    """

    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    profile: Mapped["Profile"] = relationship(back_populates="user", uselist=False)
    evaluations: Mapped[list["Evaluation"]] = relationship(back_populates="user")


class Profile(Base):
    """
    Renter profile model containing financial and document information.
    """

    __tablename__ = "profiles"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), unique=True, nullable=False)

    renter_type: Mapped[str] = mapped_column(String(50), nullable=False)
    monthly_income: Mapped[float] = mapped_column(Float, nullable=False)
    documents_json: Mapped[dict] = mapped_column(JSON, default=dict)
    is_bursary_student: Mapped[bool] = mapped_column(Boolean, default=False)
    guarantor_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )

    user: Mapped["User"] = relationship(back_populates="profile")
    evaluations: Mapped[list["Evaluation"]] = relationship(back_populates="profile")


class Evaluation(Base):
    """
    Evaluation model capturing the result of evaluating a listing for a profile.
    """

    __tablename__ = "evaluations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)

    # Guest evaluations may have no user or profile associated
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    profile_id: Mapped[int | None] = mapped_column(ForeignKey("profiles.id"), nullable=True)

    listing_json: Mapped[dict] = mapped_column(JSON, nullable=False)
    score: Mapped[float] = mapped_column(Float, nullable=False)
    verdict: Mapped[str] = mapped_column(String(50), nullable=False)
    confidence: Mapped[str] = mapped_column(String(50), nullable=False)

    reasons_json: Mapped[list] = mapped_column(JSON, default=list)
    actions_json: Mapped[list] = mapped_column(JSON, default=list)
    breakdown_json: Mapped[dict] = mapped_column(JSON, default=dict)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    user: Mapped["User"] = relationship(back_populates="evaluations")
    profile: Mapped["Profile"] = relationship(back_populates="evaluations")
