"""
Database engine and session management.

This module sets up the SQLAlchemy engine and a session factory. It provides
a dependency for FastAPI routes to access the database session.
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from app.core.config import settings


class Base(DeclarativeBase):
    """
    Base class for ORM models. Inherit from this to create new models.
    """

    pass


# Create SQLAlchemy engine using the configured database URL
engine = create_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,
)

# Session factory for creating new database sessions
SessionLocal = sessionmaker(
    bind=engine,
    autoflush=False,
    autocommit=False,
)


def get_db():
    """
    Dependency that yields a database session for FastAPI.
    The session is automatically closed after the request.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
